 #include <stdio.h>
#include <string.h>

int main()
{
    char text[100], key[26];
    int i;

    printf("Enter the plaintext: ");
    scanf("%s", text);

    printf("Enter the substitution key (26 letters): ");
    scanf("%s", key);

    for(i = 0; text[i] != '\0'; i++)
    {
        if(text[i] >= 'A' && text[i] <= 'Z')
        {
            text[i] = key[text[i] - 'A'];
        }
    }

    printf("Ciphertext: %s\n", text);

    return 0;
}
